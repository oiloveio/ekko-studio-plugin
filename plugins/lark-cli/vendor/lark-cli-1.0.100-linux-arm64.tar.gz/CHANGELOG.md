# Changelog

All notable changes to this project will be documented in this file.

## [v1.0.100] - 2026-11-10

### Bug Fixes

- **apps**: name export's real gate and reject unusable ids and paths (#2899)
- scope apps recovery hints to failure causes (#2897)
- **apps**: classify database precondition subcodes (#2900)
- **apps**: recognize feishuapp runtime domains (#2906)

### Misc

- remove unused skills (#2908)

## [v1.0.99] - 2026-11-04

### Features

- **task**: register comment API metadata (#2864)
- **apps**: add +features and +feature-enable for app business features (#2816)
- **apps**: support changing app icon via +update --icon-url/--icon-file (#2857)
- **apps**: add --owner-id filter to apps +list (#2884)
- **apps**: add +delete shortcut (#2883)

### Bug Fixes

- **auth**: explain logins that receive no refresh_token (#2853)
- **apps**: tell git to quit when the credential helper cannot answer (#2854)
- **apps**: answer rate-limited calls with backoff instead of request hints (#2882)
- fill missing agent names for legacy callers (#2889)

### Documentation

- **apps**: align cloud-dev polling guidance with session-get response (#2851)

### Refactoring

- **docs**: remove genre routing and ignore unknown fields (#2859)

### Misc

- **slides**: sync XML schema (2026-10-13) (#2806)

## [v1.0.98] - 2026-10-13

### Features

- **base**: default record reads to ndjson (#2782)
- **auth**: add DPoP support (#2679)
- support URL rewriting extensions (#2595)
- support manifest-based distribution updates (#2596)

### Documentation

- **task**: clarify section routing and workflows (#2795)
- **base**: add text cell mention example (#2802)
- **apps**: restrict creative-mode wording in skill guidance (#2801)

## [v1.0.97] - 2026-09-28

### Features

- optimize the transfer event (#2750)
- propagate policy status_message to agents (#2384)
- support release approval handoff (#2639)

### Bug Fixes

- **drive**: accept successful folder moves without a task ID (#2751)
- **apps**: stop the db/file commands from misdirecting the caller on failure (#2719)
- **errors**: prefer rendered OpenAPI messages (#2629)
- support unified input for IM messages (#2760)
- **im**: expose open IDs for calendar messages (#2752)

### Documentation

- remove post-meeting event grace guidance (#2749)

## [v1.0.96] - 2026-09-16

### Features

- **base**: support dashboard NPS config (#2562)
- **apps**: add +export to download an app's source code as a zip (#2594)
- **sheets**: accept the parameter spellings two reflow windows say callers write (#2710)
- **slides**: consolidate xml-get skill docs (#2662)

### Bug Fixes

- 优化工作流记录相关触发器的 Skill，消除歧义和语义错误 (#2670)
- **minutes**: enforce deterministic search ordering (#2714)
- **base**: repair skill references and clarify view creation (#2725)
- restrict chat creation to tenant token (#2728)
- **skills**: use GUIDE.md for nested suite guides (#2634)
- **vc**: restrict meeting join and leave to bot (#2570)
- **apps**: only treat a JSON body as export's error envelope, stream any other type (#2731)

### Documentation

- **base**: add view selection and lifecycle reference (#2729)

### Tests

- **base**: fix NPS workflow rating fixture (#2730)

## [v1.0.95] - 2026-09-10

### Features

- **sheets**: accept the payload spellings the 08-29..31 reflow rejected (#2611)
- **sheets**: add chart sizing and quality checks (#2504)
- **docs**: await asynchronous document creation (#2641)
- **im**: add concise message output (#2567)
- Supports sorting of questions in the Base form (#2598)
- add lazy API catalog routing (#2232)

### Bug Fixes

- list workspace entity 上限调整为 30 (#2646)
- **apps**: classify db failures by their k_dl subcode (#2650)
- handle credential and config read failures (#2583)
- **wiki**: resolve node-get through node_by_token (#2665)
- **docs**: resolve draft resources and validate explicit constraints (#2675)
- **wiki**: migrate mutation lookups to node_by_token (#2676)
- **base**: validate dashboard update filters (#2631)
- **base**: make table and field lists fetch all items (#2674)
- **drive**: migrate wiki lookups to node_by_token (#2682)
- **drive**: improve token recognition for download and preview (#2680)
- **sheets,slides**: migrate wiki lookups to node_by_token (#2696)
- **base**: migrate wiki lookup to node_by_token (#2699)
- **docs**: migrate wiki lookups to node_by_token (#2689)
- **base**: preserve unsupported record values in NDJSON exports (#2701)
- reduce vulnerable dependencies while retaining Go 1.23 (#2659)

### Documentation

- **im**: document folder expansion and download guidance (#2633)
- **skills**: use wiki node shortcut in guidance (#2702)

## [v1.0.94] - 2026-09-07

### Features

- 支持会议搜索使用机器人身份 (#2445)
- **vc**: distinguish detected meeting share starts (#2541)
- **slides**: lint slide writes server-side, add --no-lint to opt out (#2607)
- validate generated API parameter constraints (#2514)
- **base**: support AI classification and AI Analysis Action (#2590)
- add mail rule shortcuts (#2327)
- **calendar**: remove app_link from event outputs, emphasize share link (#2618)
- expand folder children one level in IM message output (#2606)
- use remote scopes.json for login scope recommendations (#1799)

### Bug Fixes

- **base**: repair field schema template reference (#2575)
- **base**: improve search recovery and form deletion safety (#2422)
- honor requiredScopes conjunction in CollectScopesForProjects (#1878)
- **output**: preserve non-data payloads in the api success envelope (#2601)
- **suggest**: surface both halves of a welded compound flag name (#2604)
- optimize calendar and vc (#2616)

### Documentation

- **skills**: fix broken reference links (#2485)

### Misc

- Add mail thread management shortcuts (#2370)
- **slides**: sync XML schema (2026-09-01) (#2589)

## [v1.0.93] - 2026-09-01

### Features

- **docs**: route local Word media uploads to office mount point (#2568)
- **base**: support ranking dashboard blocks (#2528)
- **sheets**: cut the top command-error clusters from the 08-18..24 eval batch (#2559)
- add shortcut for +list-attendees (#2591)
- **vfs**: allow absolute paths under a built-in path policy (#2580)

### Bug Fixes

- **event**: preserve UTF-8 in truncated diagnostics (#2535)
- **base**: correct reminder trigger offset direction (#2584)
- **shortcuts**: remove non-actionable stderr progress (#2532)

### Documentation

- **lark-doc**: retain draft workspaces after creation (#2574)
- **sheets**: clarify dropdown values and default colors (#2582)

### Refactoring

- **sheets**: remove legacy sheets command surface (#2572)

### Misc

- Feat/okr comment (#2558)

## [v1.0.92] - 2026-08-28

### Features

- **sheets**: add +cond-format-result-get and --include conditional_format (#2502)
- **im**: support rich-text message attachment zone in send/reply/mge… (#2515)

### Bug Fixes

- **slides**: relax office token length check from 28 to >=25 (#2531)
- **sheets**: make image-upload previews match what Execute sends (#2537)
- **sheets**: suppress multipart stderr noise and tighten e2e boundary test (#2550)

### Refactoring

- **sheets**: keep the success path off stderr (#2533)

## [v1.0.91] - 2026-08-27

### Features

- **im**: add chat AppLink output (#2491)
- **sheets**: relax local-office token length check from 28 to >=25 (#2509)
- **calendar**: add +join-event shortcut and share token support (#2508)
- **base**: streamline record workflows (#2529)
- **base**: add field extension shortcuts (#2463)
- add im message patch meta api (#2407)

### Bug Fixes

- **docs**: recover PowerShell-dequoted presentation JSON (#2501)

### Documentation

- **approval**: document keyword search and add-sign flow (#2388)

## [v1.0.90] - 2026-08-25

### Features

- event organizer transfer bot to user (#2448)
- **base**: document app default page reuse (#2436)
- **slides**: un-deprecate +replace-pages shortcut (#2470)
- **slides**: add media download shortcut (#2446)
- **vc**: add agent meeting control shortcuts (#2466)
- **slides**: add marginRight attribute to <p> element schema (#2493)
- words replace and minutes fix (#2490)
- **sheets**: combine chart workflows and special chart types (#2374)
- **extension**: add business command extension v1 (#2308)
- **drive**: support appid in member-remove (#2499)
- **config**: support keychain-backed tenant access tokens (#2488)

### Bug Fixes

- **apps**: classify the online DDL ban and the file storage quota failure (#2460)
- **base**: hide dashboard auto analysis setting (#2465)
- **slides**: strip stale <note> id in +update-slide to avoid backend crash (#2475)
- **drive**: continue downloads on permission scope errors (#2494)
- **wiki**: keep node-get stderr machine-readable (#2449)
- **slides**: avoid PID variable in examples (#2496)
- **docs**: continue media downloads on permission scope errors (#2498)
- **skills**: scope markdown routing to Lark resources (#2497)
- **auth**: exclude im:message.send_as_user from batch scope sets (#2471)

### Refactoring

- **slides**: assert dry-run parent_type instead of deriving it from a placeholder (#2461)

### Misc

- Support repeated mail compose flags (#2271)

## [v1.0.89] - 2026-08-21

### Features

- add minutes transcript degradation logic (#2404)
- **base**: add --position and statistics number_format to dashboard-block create/update (#2118)
- **base**: add dashboard and form share shortcuts (#2282)
- **skills**: unify meeting related skills (#2387)
- **base**: support button workflow bindings (#2437)
- **base**: add template discovery and form question field reuse (#2340)
- **skills**: extend slides XML schema (#2442)
- **slides**: use office_slide_file parent_type for imported office presentations (#2441)
- add IM read status shortcuts (#2318)

### Bug Fixes

- honor recovered E2E retries (#2400)
- **apps**: make cache-clear ask first, and make apps failures classifiable (#2415)

### Tests

- **drive**: retry transient async cleanup contention (#2397)

### Refactoring

- **shortcuts**: remove MCP text location paths (#2439)

## [v1.0.88] - 2026-08-18

### Features

- fix doc skill about identity coutinue (#2334)
- **base**: clarify skill routing and references (#2347)
- **sheets**: accept the --range / --cells / border shapes callers actually send (#2338)
- **slides**: auto-upload @path images in +update-slide (#2346)
- **docs**: support comments and block mutation ranges (#2341)
- **slides**: add kickoff reminder for empty presentations (#2367)
- support separate and suite skill layouts (#2211)

### Bug Fixes

- **base**: improve record history output and validation (#2298)
- **api**: reject query strings and fragments in paths (#2375)

### Documentation

- **base**: restructure skill routing and analysis guidance (#2320)
- **lark-shared**: split SKILL.md into a slim core plus references (#2226)

### Tests

- **docs**: align fetch help comment expectations (#2363)

## [v1.0.87] - 2026-08-13

### Features

- **base**: add typed NDJSON workflows for professional data analysis (#2196)
- propagate credential metadata (#2305)
- **calendar**: support setting VC meeting owner in +create (#2328)
- **base**: support BaseApp application mode (#2231)

### Bug Fixes

- **apps**: reject non-HTML apps in +html-publish with actionable error (#2300)
- **apps**: friendly-ize "Container not exists" for observability commands (#2302)
- **drive**: guide wiki permission recovery (#2311)
- **wiki**: guide recovery from node structural limits (#2290)
- **wiki**: bound node retries (#2292)

### Documentation

- make enterprise/embedded integration discoverable from the repo (#2066)
- **base**: add common filter condition examples (#2310)
- **lark-im**: support user and bot identities for resource uploads (#2319)
- **calendar**: clarify +create-first strategy for advanced fields (#2336)

### Misc

- add Base skill code owner (#2303)

## [v1.0.86] - 2026-08-11

### Features

- **drive**: add wiki url/token support to +download and +preview (#2220)
- report upload file events (#2093)
- **slides**: normalize replace-slide part aliases (#2225)
- **drive**: add +member-remove shortcut (#1994)
- support shared vc live references and document context (#2249)
- **wiki**: improve node creation and terminal errors (#2266)
- **base**: require --fields on +table-create (#2221)
- support bot identity (#2288)
- **affordance**: support domain skill lists (#2291)
- expose compact task fields (#2109)
- **drive**: document copy workflow guidance (#2184)
- add apps database sync shortcuts for Base-to-database import (#2251)
- **apps**: add +user-id-convert shortcut for Miaoda↔Feishu ID conversion (#2270)
- **slides**: inline slides reference docs into help output (#2181)

### Bug Fixes

- **wiki**: correct copy semantics and rename routing (#2238)
- **slides**: move add-slide and delete-slide reference docs to cli/ directory (#2272)
- **drive**: harden export and push failure recovery (#2279)
- **wiki**: clarify resource permission recovery (#2281)

### Documentation

- improve agent contribution guidance (#2259)
- document supported image formats in lark-slides media-upload (#2269)
- **calendar**: clarify identity selection for scheduling (#2280)
- **slides**: use built-in --jq in cli examples and fix workflow link labels (#2286)

### Refactoring

- reorganize lark slides skill references (#2207)

### Misc

- prune unsupported iconpark index entries (#2252)
- verify release Go toolchain (#2256)

## [v1.0.85] - 2026-08-07

### Features

- **event**: compile the catalog and harden the consume pipeline (#2142)
- support bot identity for search shortcuts (#2194)
- **drive**: add +update-title shortcut (#2172)
- **sheets**: add ai formula verify (#1959)
- **drive**: add +copy shortcut (#2129)
- add frontend as third app type for apps domain (#2072)
- **sheets**: harden error prescriptions, batch updates, and read workflows
- **slides**: accept slide XML files in +create (#2197)
- **docs**: add local authoring and resource workflows (#1921)
- preflight export permission for downloads (#2218)

### Bug Fixes

- **base**: guide complete dashboard data recovery (#2144)
- **apps**: isolate git credential helper chain for scoped repos (#2188)
- **im**: unpin search identity after bot support landed (#2208)
- **auth**: harden token refresh and concurrency handling (#2135)
- **registry**: describe the attendance and mindnotes domains (#2210)
- reject truncated wiki node tokens (#2203)
- **apps**: detect the no-database failure by code or message (#2217)
- **base**: improve field creation and query guidance (#2114)
- **slides**: restore update-slide skill guidance (#2227)
- align slides xml-get skill flags (#2237)
- **im**: harden resource downloads with validated ranged streams (#2223)

### Documentation

- **skills**: sync lark whiteboard skill (#2215)
- **doc**: clarify history edit time format (#1962)

### Misc

- feat (apps): add miaoda app collaborator management (#2230)

## [v1.0.84] - 2026-08-05

### Features

- **calendar**: allow bot auth for search-event (#2186)
- **extension**: present restricted commands as absent and trim skills (#1837)
- add Base table copy shortcuts (#2019)
- **slides**: support explicit screenshot output paths (#2180)
- profile selection from environment with source-aware errors (#2198)
- migrate application and IM guidance to affordance (#2199)

### Bug Fixes

- **slides**: bind lint issues to source XML nodes (#2179)
- **drive**: stop export polling on rate limits (#2192)
- make agent recovery and concealment reliable (#2189)
- surface retry metadata for TAT rate limits (#2200)

### Documentation

- **slides**: temporarily route skill guidance back to +replace-pages (#2187)
- **calendar**: clarify attendee resolution to avoid type guessing (#2195)
- **wiki**: route node resolution through shortcut (#2132)

## [v1.0.83] - 2026-08-04

### Features

- **slides**: add +update-slide for whole-page updates (#2143)
- **apps**: friendly error for db commands on an app with no database (#2162)
- **slides**: support embedded SVG content (#2154)

### Bug Fixes

- **slides**: add agent-friendly aliases for screenshot flags (#2156)
- **slides**: migrate SML namespace from HTTP to HTTPS (#2169)
- **slides**: improve missing screenshot selector guidance (#2177)
- **slides**: name the wrong --parts field instead of "non-empty replacement" (#2174)

### Documentation

- **base**: clarify unsupported capability boundaries (#2133)
- **slides**: correct +xml-get flag requirements (#2171)

### Misc

- notarize macOS release candidates (#2073)
- allow concurrent live e2e jobs (#2182)

## [v1.0.82] - 2026-08-03

### Features

- **enhancement**: centralize HTTP transport policies (#2021)
- add framework flag aliases and unified IM pagination (#2146)
- **slides**: add +add-slide and +delete-slide shortcuts (#2120)

### Bug Fixes

- normalize mail triage filters (#2068)
- **slides**: restore presentation aliases (#2164)

### Documentation

- remove broken Star History chart (#2141)
- **base**: harden dashboard multi-block read guidance (#2122)

### Tests

- pass contact list params explicitly (#2150)

## [v1.0.81] - 2026-07-31

### Features

- support visible_rule for form questions (#1891)
- **contact**: add bot search shortcut (#2083)
- add SXSD schema validation to Slides lint (#2103)
- **drive**: add comment-operation shortcuts (#1898)
- **drive**: extend permission shortcuts for Miaoda (#2070)
- **apps**: add cache debug commands (+cache-get/-delete/-clear) (#1896)
- support source file preview artifacts (#2085)

### Bug Fixes

- **contact**: stop bot match segments carrying tags or empty entries (#2115)
- **base**: resolve Base URL block types accurately (#2099)
- **drive**: use title for default download filename (#2089)
- drop stale target version from root upgrade prompt (#2100)

### Documentation

- **calendar**: warn against container-default timezone in time conversion (#2104)
- **calendar**: confirm scope before editing recurring events (#2119)
- **base**: clarify form and file operation routing (#2110)

### Misc

- add protected public domain allowlists (#2111)

## [v1.0.80] - 2026-07-29

### Features

- **drive**: add +member-list shortcut (#1795)
- **drive**: add +permission-get-setting shortcut (#1738)
- propagate invocation metadata (#2097)

### Documentation

- **slides**: 补齐 shortcut 参数说明，修正 +xml-get --output 必填标注 (#2088)
- **slides**: +create 的参数下沉到 create.md，主 skill 只留路由 (#2096)

### Tests

- **e2e**: wait for base role update visibility (#2087)

### Misc

- Feat/detect line text overlap (#2069)

## [v1.0.79] - 2026-07-28

### Features

- **slides**: update xsd (#2067)

### Bug Fixes

- **ci**: validate static workflow identity (#2015)
- **sheets**: recognize OFL0X local office tokens (#2063)

### Documentation

- **calendar**: clarify identity selection by event ownership (#2071)
- **slides**: add formula inline element syntax to quick-ref (#2077)

## [v1.0.78] - 2026-07-27

### Features

- event description support rich text (#1975)

### Bug Fixes

- **slides**: restrict canvas overflow checks
- **slides**: upgrade text overflow to error above 10px threshold
- **slides**: detect letterSpacing-driven text overflow
- **slides**: downgrade background-decoration text overflow to info
- **slides**: allow chartParsedValues roundtrip tag
- refine character width estimation for lark-slides text lint
- **slides**: preserve info lint severity
- **slides**: text may over flow shape
- exempt ghost text from slides lint

## [v1.0.77] - 2026-07-24

### Features

- introducing official card icon (#1973)
- **apps**: validate +file-list --page-size against server (0, 200] range (#2007)
- **apps**: support absolute and relative upload paths (#2005)
- **slides**: fill xml-schema-quick-ref gaps that forced XSD fallback (#2026)
- **slides**: add layout density lint for sparse/empty containers (#2022)
- add risk-control protection (#1910)

### Bug Fixes

- **slides**: normalize presentation flag aliases (#2032)
- **base**: classify +form-submit as high-risk-write (#1969)
- **slides**: declare screenshot scope
- **slides**: support CSV multi-value for --slide-id in screenshot (#2047)

### Documentation

- **skill**: clarify scope handling for query expansion (#2030)
- **base**: clarify complete and partial updates (#1993)
- **skills**: clarify callout child rules (#2048)

### Misc

- fix/task id handling (#2023)
- fix/task search pagination (#2041)

## [v1.0.75] - 2026-07-22

### Features

- add okr single create shortcut & skill text opti (#1941)
- **calendar**: auto-add bot self as attendee and note user-only search (#1991)

### Bug Fixes

- **base**: improve table shortcut behavior & guidance (#1803)
- issue#1935 & whiteboard shortcut reformat (#1980)
- remove legacy shortcut (#1997)
- **e2e**: inject shared credentials by identity (#1995)

### Documentation

- **skill**: describe html5 block xml usage (#1380)
- clarify fetch metadata and user cites (#1981)
- add topic move collector workflow (#1473)
- update lark doc HTML size limit (#2001)
- **base**: align record write schema guidance (#2000)

### Tests

- **e2e**: declare request identities explicitly (#2004)

### Misc

- harden npm release publishing (#1918)

## [v1.0.74] - 2026-07-21

### Features

- **slides**: add history rollback shortcuts (#1714)
- **base**: support per-record batch updates (#1889)

### Bug Fixes

- preserve slides schema issues
- allow jq examples in quality gate dry-runs
- **im**: warn when flag pagination is truncated (#1906)
- **slides**: warn on text shape overflow
- **slides**: exempt chart roundtrip attributes from lint
- **slides**: detect image text occlusion
- **slides**: clarify xml-text-overlap-lint error for positional argument (#1986)

### Documentation

- clarify drive upload overwrite guidance (#1982)

### Tests

- isolate unit tests from user state (#1883)

### Refactoring

- converge success output through a single Emitter that owns the write (#1899)

## [v1.0.73] - 2026-07-20

### Features

- **apps**: design_html support, creative-design skill, unified TOS publish (#1901)

### Bug Fixes

- **slides**: detect visual elements outside canvas
- reduce public content credential fixture false positives
- standardize CLI shortcut text in English (#1942)

### Documentation

- **base**: reduce filter and update retry loops (#1879)
- **vc**: default transcript routing to smart notes over minutes (#1961)
- clarify local trigger automation (#1958)

### Tests

- synchronize temporary Git maintenance (#1946)

### Misc

- **slides**: update lark-slides skill to 0715 snapshot (#1933)
- [codex] support bot menu events (#1765)

## [v1.0.72] - 2026-07-17

### Features

- **slides**: lint table out of canvas
- **slides**: report resolved table size mismatches
- **approval**: support approval event consumption (#1924)

### Bug Fixes

- **vc**: don't fail +detail for in-progress meetings (#1930)
- stabilize drive delete E2E terminal-state checks (#1939)

### Documentation

- **slides**: document table dimensions
- document base field default values (#1500)
- **sheets**: use English placeholder in table-get guidance (#1936)

### Tests

- stabilize live e2e auth retries (#1904)
- use tri-state wiki node identity in delete verification (#1931)
- fix drive cover download retries (#1934)

## [v1.0.71] - 2026-07-16

### Features

- add wiki move-to-drive shortcut (#1869)
- **apps**: add role management shortcuts (#1881)
- **drive**: add secure label support and clarify comment location API (#1913)

### Bug Fixes

- **base**: improve dashboard shortcut guidance (#1787)

### Documentation

- **apps**: add platform SQL authoring guide to the db-execute skill (#1912)

### Misc

- add L4 plugin-integration and sidecar-integration CI jobs (#1840)
- **drive**: optimize drive +delete workflow (#1909)

## [v1.0.70] - 2026-07-15

### Features

- add minutes permission application shortcut (#1876)
- **drive**: support apps in list comments (#1877)
- slide style
- edit ppt template
- **slides**: add sxsd validation to slides lint
- **slides**: validate iconpark icon types in slides lint
- **slides**: lint before create
- **apps**: add automation trigger commands for Miaoda (#1886)

### Bug Fixes

- unify dry-run output contract (#1870)
- **skills**: align skill guidance with the typed error contract (#1786)
- **slides**: limit slides screenshot page requests
- **slides**: detect lark slides text overflow overlap
- **vc**: align meeting query scopes by identity (#1850)

### Documentation

- clarify task search relevance filters (#1884)
- surface minutes permission application in skill description (#1890)
- clarify okr progress children (#1861)
- **slides**: prefer slides xml-get shortcut
- **calendar**: document setting meeting owner via full API (#1903)

### Refactoring

- **slides**: streamline create workflow and validate SML namespaces

### Misc

- **slides**: address PR review feedback

## [v1.0.69] - 2026-07-13

### Features

- support docs fetch selection anchors (#1815)
- **apps**: support modern_html app type with TOS publish path and app type querying
- **im**: show bot sender display names when reading messages (#1829)
- add drive list comments shortcut (#1845)
- support wiki sources in drive export (#1802)
- add application domain with slash command management shortcuts (#1806)
- validate IM idempotency key length (#1797)
- surface reply context and mentions in im.message.receive_v1 (#1798)

### Bug Fixes

- route brand-sensitive endpoints through the resolver (#1836)

### Documentation

- document OKR block XML guidance (#1648)
- refine doubao whiteboard workflow routing (#1841)
- clarify Mindnote token handling (#1827)

### Tests

- isolate semantic waiver fixtures from wall clock

### Misc

- Merge lark sheets development branch (#1833)

## [v1.0.68] - 2026-07-09

### Features

- **drive**: Strengthen lark-drive high-risk write operations and read-only recognition boundaries. (#1801)
- **slides**: add slides chart demo reference

### Bug Fixes

- register and consume --json shorthand for custom-format shortcuts (#1737)
- **drive**: abort push on parent sibling limit (#1813)

### Documentation

- require native charts in slide planning
- register knowledge organize workflow (#1828)

## [v1.0.67] - 2026-07-08

### Features

- **mail**: add message modify and trash shortcuts (#1567)
- support whiteboard file inputs in docs XML (#1784)
- **vc**: refine meeting-events output and reaction forwarding (#1674)
- **affordance**: usage guidance for shortcuts and per-command skills (#1793)

### Bug Fixes

- accept opaque wiki node tokens (#1789)
- **apps**: make db --environment optional, auto-select branch server-side (#1735)
- preserve original filename in multipart file upload (#1767)

### Documentation

- restore one-time authorization guidance in lark-apps skill (#1794)

### Misc

- e2e: harden CLI E2E retry, cleanup, and domain selection (#1709)

## [v1.0.66] - 2026-07-07

### Features

- support semantic recurring calendar operations (#1723)
- minute wait (#1768)

### Bug Fixes

- guide drive import concurrency conflicts (#1751)
- **calendar**: guide approval room booking fallback (#1637)
- support pnpm global installs in self-update (#1705)
- resolve schema against runtime metadata in plugin builds; gate cache overlay by version (#1764)

### Documentation

- tighten doc creation validation workflow (#1759)
- clarify success envelope contract — judge success by ok, not code (#1730)

### Refactoring

- **envvars**: consolidate agent env value access (#1757)

### Misc

- Improve agent-facing error guidance for drive, markdown, and wiki (#1779)

## [v1.0.65] - 2026-07-03

### Features

- **doc**: Add `+history-list`, `+history-revert`, and `+history-revert-status` shortcuts for document version history (#1612)

### Bug Fixes

- **minutes**: `+speaker-replace` no longer refetches the speaker list — `--from-speaker-id` is passed through as-is (#1731)

### Documentation

- **drive**: Document 30-char query limit for `+search` (#1560)
- **doc**: Add mindnote guidance to lark-doc skill (#1581)
- **doc**: Sync lark-doc skill content from online-doc (#1701)

## [v1.0.64] - 2026-07-02

### Features

- **im**: Upgrade card send to Card 2.0 with full component reference (#1688)
- **im**: Add `+chat-members-list` shortcut for member listing (#1398)
- **okr**: Semi-plain text format with mention position preservation and `patch` shortcut (#1671)

### Bug Fixes

- **cli**: Point permission-apply link at official `/page/scope-apply` entry (#1722)
- **cli**: Improve secure label error handling (#1707)
- **cli**: Reduce public content token false positives
- **cli**: Increase npm registry fetch timeout to 15s during update check (#1724)
- **doc**: Align word statistics compound tokens (#1706)

### Documentation

- **approval**: Add detailed command-to-reference mapping for the approval skill (#1630)
- **doc**: Support `reference_map` in docs (#1690)
- **slides**: Refresh generation guidance — add constraints, drop template toolchain, and inline lint XML fixtures

## [v1.0.62] - 2026-07-01

### Features

- **vc**: Add meeting message send shortcut (#1643)
- **doc**: Add document word statistics helper (#1697)
- **cli**: Interactive upgrade prompt for bare `lark-cli` invocation (#1498)
- **install**: Fail closed when `checksums.txt` is missing during install (#1503)

### Bug Fixes

- **drive**: Improve batch failure handling for push/pull/sync (#1703)
- **base**: Support JSON array input for field create (#1661)
- **task**: Expose completion state in `my tasks` output (#1641)
- **cli**: Reduce public content credential false positives (#1700)

## [v1.0.61] - 2026-06-30

### Features

- **apps**: Add `db`, `file`, `openapi-key` and observability shortcuts (#1596)
- **identity**: Add `whoami` command showing effective identity (#1666)
- **docs**: Add reference map flags (#1547)

### Bug Fixes

- **identity**: Correct identity diagnosis under external credential providers (#1693)
- **cli**: Harden git credential error handling (#1676)

### Documentation

- **doc**: Guide document copy skill usage (#1673)
- **doc**: Fix lark-doc media token examples (#1662)

## [v1.0.60] - 2026-06-29

### Features

- **affordance**: Per-command usage guidance system with markdown source (#1565)
- **event**: Support VC meeting lifecycle events (#1632)
- **sheets**: Use `office_sheet_file` parent_type for imported office spreadsheets (#1606)
- **authorization**: Expand lark-shared auth guidance and assert clean logout JSON (#1598)
- **transport**: Add `LARK_CLI_NO_PROXY_WARN` to silence proxy warning (#1647)

### Bug Fixes

- **install**: Load `@clack/prompts` via dynamic import to avoid `ERR_REQUIRE_ESM` (#1652)

### Tests

- **doc**: Derive fetch test flag defaults from `v2FetchFlags` (#1428)

### Build

- **ci**: Reduce public content false positives

## [v1.0.59] - 2026-06-26

### Features

- **slides**: Add `+replace-pages` and `xml get` shortcuts, and expose the presentation URL (#1585)
- **minutes**: Support speaker list and no-Lark speaker replace (#1594)
- **calendar/vc/minutes**: Optimize and extend calendar, vc, minutes, and note shortcuts and skills (#1571)

### Bug Fixes

- **docs**: Hide docs `api-version` compat flag (#1580)

## [v1.0.58] - 2026-06-25

### Features

- **sheets**: Typed table I/O and error contract, workbook import/export, and skill refresh (#1355)
- **base**: Add Base URL and title resolve shortcuts (#1338)
- **drive**: Add `+member-add` shortcut with wiki space member collection collaborator support (#1204)
- **doc**: Support `create` title option (#1536)
- **doc**: Add `im-markdown` output format for doc fetch (#1550)
- **whiteboard**: Export whiteboard as SVG and update whiteboard via SVG (#1559)
- **card**: Support `card.action.trigger` event with auto-fetched card content (#1528)
- **task**: Add task event consumer (#1510)

### Bug Fixes

- **doc**: Prefix docs resource shortcuts (#1564)
- **binding**: Skip unix mode audit on Windows (#1525)

### Documentation

- **approval**: Sync approval skill for meta API commands (#1499)
- **doc**: Restore lark-doc style requirements (#1579)
- **im**: Document `chat.nickname` get/update/delete (#1378)
- **im**: Clarify audio message opus requirement (#1271)

### Build

- **ci**: Add public content safeguards and reduce false positives

## [v1.0.57] - 2026-06-23

### Features

- **slides**: Add `+screenshot` to capture slide page images (or render a single `<slide>` XML snippet), returning the local file path instead of Base64 (#1358)
- **base**: Support record comments (#1043)
- **search**: Surface search API notices (#1413)

### Bug Fixes

- **mail**: Resolve folder/label filter once per `+triage list` call (#1512)
- **meta**: Backfill enum value descriptions from options (#1541)
- **cli**: Add missing CLI headers for git credential helper (#1539)

### Documentation

- **doc**: Refine rich block, path, and block ID guidance (#1508)
- **mail**: Trim lark-mail skill context (#1527)
- **drive**: Add permission governance workflow guidance (#1292)

### Build

- **ci**: Bind semantic review to workflow run head (#1551)

## [v1.0.56] - 2026-06-18

### Features

- **apps**: Add `+session-messages-list` for session turn reply messages (#1402)

### Bug Fixes

- **api**: Align API success envelopes (#1489)
- **base**: Reject out-of-range pagination flags (#1495)

### Refactor

- Retire legacy error envelopes and enforce typed contract (#1449)

### Documentation

- **skills**: Soften lark-doc style guidance (#1463)

### Build

- Add CI quality gate with semantic review

## [v1.0.55] - 2026-06-16

### Features

- **vc**: Support agent meeting event workflows (#1483)
- **drive**: Support exporting Base structure snapshots (#1481)
- **doc**: Add docx cover resource commands (#1468)
- **doc**: Support `lang` for docx fetch v2 (#1459)
- **event**: Optimize subscription precheck, links, and consumer guard (#1447)

### Bug Fixes

- **drive**: Validate drive import folder target (#1485)

## [v1.0.54] - 2026-06-15

### Features

- **mail**: Auto-attach default signature on send/reply/forward (#1415)
- **drive**: Support `original_creator_ids` filter in search (#1046)
- **cli**: Simplify proxy plugin warning and gate it on TTY (#1448)

### Bug Fixes

- **doc**: Fix docs fetch and update ergonomics (#1466)
- **vfs**: Reject blank local paths (#1460)
- **vfs**: Reject Windows absolute paths cross-platform (#1401)
- **event**: Clarify remote bus blocker recovery (#1454)

### Refactor

- Converge command pipelines onto a typed metadata model + catalog (#1191)

### Documentation

- **im**: Document `@mention` format per message type (text/post/card) (#1419)
- **doc**: Clarify lark-doc create title guidance (#1474)
- **skills**: Add rename prompt for import without `--name` (#1461)
- **apps**: Drop Miaoda brand word from apps command help text (#1399)

## [v1.0.53] - 2026-06-12

### Features

- **auth**: Revoke user tokens server-side on `auth logout` (#1434)
- **auth**: Add `--json` flag support to auth subcommands (#1431)
- **token**: Mint TAT via unified OAuth v3 Token Endpoint (#1408)
- **note**: Split note into a dedicated domain with `+detail` and `+transcript` flows (#1345, #1417, #1435)
- **im**: Unify sort flags into `--sort` field and `--order` direction (#1302)

### Bug Fixes

- **apps**: Read release error_logs from `data.error_logs` in `+release-get` (#1436)

### Documentation

- **skills**: Optimize whiteboard skill (#1371)
- **skills**: Optimize okr skill (#1368)

## [v1.0.52] - 2026-06-11

### Features

- **events**: Per-resource subscription identity + Match hook (#1185)
- **apps**: Emit typed error envelopes across the apps domain (#1288)
- **wiki**: Emit typed error envelopes across the wiki domain (#1350)
- **im**: Add `--chat-modes` filter to chat search (#1317)
- **apps**: Exclude `.git` directory from `+html-publish` package (#1396)
- **build**: Support riscv64 prebuilt binaries in release and install pipeline

### Bug Fixes

- **apps**: Support git credential dry-run (#1390)
- **whiteboard**: Fix parsing empty whiteboard content (#1391)
- **build**: Make `-race` flag arch-conditional to support riscv64

### Documentation

- **im**: Document `chat.user_setting` batch_query/batch_update (#1339)
- **im**: Document `chat.managers` and `chat.moderation` API resources (#1294)
- **skills**: Optimize lark-drive skill routing (#1284)
- **skills**: Expand cite user guidance and fix typos (#1394)

## [v1.0.51] - 2026-06-10

### Features

- **apps**: Support multi dev modes (#1175)
- **im**: Complete audio/post rendering and add opt-in `--download-resources` (#1245)
- **base**: Configure initial base table schema (#1377)
- **vc**: Add recording event support (#1369)
- **minutes**: Replace words for transcript (#1372)
- **markdown**: Emit typed error envelopes across the markdown domain (#1347)
- **sheets**: Emit typed error envelopes across the sheets domain (#1348)
- **slides**: Emit typed error envelopes across the slides domain (#1349)

### Documentation

- **skills**: Warn about `@file` absolute path restriction in lark-doc skills (#1375)
- **skills**: Remove unsupported ⚠️ from callout emoji list (#1374)

## [v1.0.50] - 2026-06-09

### Features

- **doc**: Emit typed error envelopes across the doc domain (#1346)
- **event**: Emit typed error envelopes across the event domain (#1289)
- **contact**: Emit typed error envelopes across the contact domain (#1287)
- **sheets**: Guard `+csv-put --csv` against a path passed without `@` (#1337)
- **cli**: Adjust agent timeout hint output conditions (#1328)

### Bug Fixes

- **drive**: Add `@file`/stdin support to `+add-comment --content` (#1343)
- **slides**: Build create URL locally instead of drive metas call (#1329)
- **cli**: Clarify `--block-id` supports comma-separated batch delete in help text (#1336)

### Documentation

- **doc**: Replace append with `block_insert_after` in skeleton workflow guidance (#1340)
- **doc**: Document `<folder-manager>` resource block (#1168)
- **drive**: Add drive comment location guidance (#1258)

## [v1.0.49] - 2026-06-08

### Features

- **events**: Add whiteboard event domain with per-board subscription (#1265)
- **im**: Support feed group (#1102)
- **im**: Add feed shortcut create, list, and remove shortcuts (#1273)
- **im**: Format feed group error handling (#1308)
- **im**: Return typed error envelopes across the im domain (#1230)
- **base**: Emit typed error envelopes across the base domain (#1248)
- **calendar**: Emit typed error envelopes across the calendar domain (#1232)
- **task**: Emit typed error envelopes across the task domain (#1231)
- **okr,whiteboard**: Emit typed error envelopes across both domains (#1236)
- **minutes,vc**: Emit typed error envelopes across both domains (#1234)
- **markdown**: Harden create upload failures (#1325)
- **drive**: Harden inspect shortcut failures (#1324)
- **slides**: Add IconPark lookup for Lark slides (#1123)
- **doc**: Remove docs v1 API (#1291)
- **cli**: Add `skills` command to read embedded skill content (#1318)
- **cli**: Fetch official skills index (#1301)
- **shared**: Document relative-path-only file arguments (#1319)
- **scopes**: Clear `recommend.allow` scope auto-approve overrides (#1272)
- **shortcuts**: Check shortcut example commands against the live CLI tree (#1244)

### Bug Fixes

- **events**: Keep bounded event consume runs alive after stdin EOF (#1285)
- **drive**: Use docs secure label read scope (#1281)

### Documentation

- **approval**: Restructure skill with intent table and scope boundaries (#1307)
- **skills**: Tighten drive and markdown guardrails (#1326)
- **skills**: Optimize calendar, vc, and minutes skill guidance (#1269)
- **markdown**: Add markdown domain template (#1293)
- **markdown**: Improve lark-markdown skill guidance (#1279)
- **doc**: Improve lark-doc skill guidance (#1283)
- **wiki**: Optimize skill guidance and routing boundaries (#1275)
- **slides**: Tighten routing/boundary and reconcile in-slide whiteboard (#1169)

## [v1.0.48] - 2026-06-04

### Features

- **mail**: Preserve mailbox context in `+triage` output for public mailboxes (#1238)
- **contact**: Add contact skill domain guidance (#1144)

### Bug Fixes

- **skills**: Use JSON skills list during update (#1251)

### Documentation

- **drive**: Refine lark-drive knowledge organize workflow (#1253)
- **vc-agent**: Require explicit leave request (#1260)
- **slides**: Add whiteboard element documentation and improve slide guidance (#1029)

## [v1.0.47] - 2026-06-03

### Features

- **sheets**: Add spec-driven shortcut package with backward-compatible wrapper (#1220)
- **base**: Add base block shortcuts (#1044)
- **im**: Complete card message format (#1198)
- **im**: Improve markdown guidance for messages (#1237)
- **vc**: Forward invite call-id on meeting join (#1243)
- **drive**: Emit typed error envelopes across the drive domain (#1205)
- **common**: Emit typed validation errors from shared shortcut pre-checks (#1242)
- **mail**: Validate `message_ids` in `+messages` before batch get (#1202)
- **wiki**: Support `appid` member type (#1235)
- **cli**: Add `--json` flag as no-op alias for `--format json` (#1104)
- **config**: Validate credentials after `config init` (#1151)

### Bug Fixes

- **skills**: Recover empty fallback for skills to update (#1233)

## [v1.0.46] - 2026-06-02

### Features

- **im**: Add card message format support (#1218)
- **im**: Resolve markdown blank-line formatting inconsistency in post messages (#1216)
- **vc**: Inline transcript from artifacts API and add keywords (#1206)
- **transport**: Add proxy plugin mode for CLI HTTP transport (#1181)
- **agent**: Increase agent trace max length to 1024 (#1211)
- **shortcuts**: Unconditionally inject `--format` flag for all shortcuts (#1156)

### Bug Fixes

- **cli**: Remove FLAGS section from root `--help` (#1226)
- **cli**: Stop root `--help` listing per-command flags as global (#1223)

### Refactor

- **transport**: Own all HTTP transport in `internal/transport`, fix util layering inversion (#1213)

### Documentation

- **base**: Optimize base skill references (#1171)
- **drive**: Add Lark Drive knowledge organization workflow (#1028)

## [v1.0.45] - 2026-06-01

### Features

- **errors**: Add typed envelope contract for auth-domain errors (#1135)
- **platform**: Support multiple policy rules per plugin (#1182)

### Bug Fixes

- **vc**: Add domain boundaries and enrich `+notes` (#1172)
- **whiteboard**: Fix whiteboard skill (#1180)

### Refactor

- **auth**: Update login hint and split-flow docs (#1201)

## [v1.0.44] - 2026-05-29

### Features

- **base**: Add dashboard block data shortcut and workflow docs (#1067)
- **im**: Support `--types` flag for listing p2p single chats in `chat-list` (#1077)
- **agent**: Add agent header support (#1158)

### Bug Fixes

- **im**: Correct 64-bit MP4 box size handling to prevent panic on crafted media (#1165)
- **install**: Detect curl version before using `--ssl-revoke-best-effort` (#1124)
- **vc**: Correct `--minute-token` to `--minute-tokens` in recording reference (#1170)
- **whiteboard**: Fix whiteboard skill (#1166)

## [v1.0.43] - 2026-05-28

### Features

- **event**: Support `note` generated event (#1159)
- **config**: Decouple `--lang` preference from TUI display language (#1132)
- **mail**: Add HTML lint library with Larksuite-native autofix for `lark-mail` (#1019)

### Bug Fixes

- **config**: Propagate `Lang` across credential boundary; respect `CurrentApp` in priorLang (#1157)
- **config**: Allow lark-channel bind source override (#1154)
- **im**: Clarify `messages-send` dry-run chat membership (#1150)
- **base**: Include `log_id` in attachment media errors (#1133)

### Performance

- **im**: Parallelize reactions, thread_replies, and merge_forward fetches (#1146)

### Documentation

- **im**: Update IM skill urgent APIs (#1153)

## [v1.0.42] - 2026-05-27

### Features

- **mail**: Add `+draft-send` shortcut for batch draft sending (#1017)
- **im**: Enrich messages with reactions and output `update_time` (#1095)
- **schema**: Output JSON spec envelope for all API commands (#1048)
- **event**: Support `vc` / `note` / `minute` events (#1113)
- **drive**: Add secure label shortcuts (#985)
- **affordance**: Use description and command in affordance example schema (#1126)

### Bug Fixes

- **docs**: Remove unsupported `fetch` text format (#1109)

### Refactor

- **auth**: Drop duplicate top-level user fields in `status` (#1128)

### Documentation

- **doc**: Document block anchor URLs in `lark-doc` skill (#1120)
- **whiteboard**: Improve SVG/Mermaid instructions (#1097)

## [v1.0.41] - 2026-05-26

### Features

- **minutes**: Add minutes edit shortcuts (#1036)
- **minutes**: Get minutes keywords (#1079)
- **slides**: Support importing pptx as slides (#1068)
- **config**: Add `keychain-downgrade` subcommand (macOS) (#1085)
- **errors**: Add structured CLI error contract (#984)
- **apps**: Replace `+html-publish` cwd hard-reject with credential-file scan (#1072)

### Bug Fixes

- **drive**: Support doubao drive inspect URL variants (#1106)
- **skills**: Sync skills incrementally during update (#1042)
- **apps**: Read app object from `data.app` for `+create` and `+update` (#1087)
- **common**: Escape special chars in multipart form filenames (#1037)
- **auth**: Remove fenced code block guidance from auth URL output hints (#1088)

### Documentation

- **skills**: Fix agent routing for doubao.com URLs (#1082)
- **task**: Require `--complete=false` for pending standup summaries (#1101)
- **base**: Document UI-only field settings (#1078)
- **contributing**: Clarify contributor guidance (#1096)

## [v1.0.40] - 2026-05-25

### Features

- **wiki**: Add exponential backoff retry for `+node-create` lock contention (#1012)
- **auth**: Add `auth qrcode` subcommand and update auth docs/hints (#968)

### Bug Fixes

- **wiki**: Rename `+node-get --token` to `--node-token`, keep alias (#1074)
- **output**: Classify wiki lock-contention error (131009) with retry hint (#1014)
- **contact**: Add actionable hint when fanout search all-fail with no API code (#1054)
- **permission**: Annotate auto-grant permission failures with `required_scope` and `console_url` (#1045)
- **validation**: Use `ErrValidation` instead of `fmt.Errorf` in `Validate` paths (#1001)

### Documentation

- **skills**: Add 云盘/云存储 alias alongside 云空间 for agent clarity (#1073)
- **task**: Refresh `lark-task` shortcut docs (#1057)

## [v1.0.39] - 2026-05-22

### Features

- **slides**: Add `+export` shortcut to export slides (#988)
- **sidecar**: Support multi-client identity isolation in `server-demo` via per-client HMAC keys, preventing UAT cross-contamination when multiple CLI sandboxes share one sidecar (#934)
- **im**: Support Markdown image rendering in post content (#893)

### Bug Fixes

- **scope**: Add 22 new scope entries to scope priorities (#1050)

### Documentation

- **base**: Update location `full_address` guidance (#754)
- **apps**: Refine `lark-apps` skill description and surface, document `index.html` / `--path` hard constraints (#1040)

## [v1.0.38] - 2026-05-22

### Features

- **apps**: Gate the Miaoda apps domain off on the Lark brand — the `apps` shortcut subtree returns a structured brand-restriction error, `auth login --domain apps` is rejected, `--domain all` skips it, and `spark:*` scopes are no longer requested (#1025)

## [v1.0.37] - 2026-05-21

### Features

- **apps**: Add miaoda apps domain with 6 shortcuts covering `+create` / `+update` / `+list` / `+access-scope-get` / `+access-scope-set` / `+html-publish` (#1002)

### Bug Fixes

- **permission**: Surface auto-grant skipped/failed cases via stderr warnings and a `hint` field in the `permission_grant` JSON output (#1015)
- **sheets**: Use `FileIO` for `+write-image` input so stdin / `-` works consistently (#996)

## [v1.0.36] - 2026-05-21

### Features

- **drive/markdown**: Return real tenant URLs for `drive +upload` and `markdown +create` (#992)

### Bug Fixes

- **auth**: Return validation error when `--scope` is empty in `auth check` (#999)

### Documentation

- **lark-drive**: Improve search evidence guidance (#864)

## [v1.0.35] - 2026-05-20

### Features

- **markdown**: Support wiki node target in `+create` (#883)
- **markdown**: Add `+diff` shortcut (#876)
- **base**: Add form `+detail` / `+submit` shortcuts (#759)
- **skills**: Add incremental skills sync (#965)
- **doc**: Warn before overwrite when document contains whiteboard or file blocks (#825)

### Documentation

- **im**: Clarify media key formats for message media flags (#991)
- **im**: Add media-preview reference (#990)
- **drive**: Migrate `docs +search` to `drive +search` and fix `creator_ids` owner semantic (#951)
- **drive**: Prefer local comments for drive reviews (#981)
- **wiki**: Add wiki base fast path (#982)

## [v1.0.34] - 2026-05-19

### Features

- **drive**: Switch markdown export to V2 `docs_ai` fetch API (#948)
- **drive**: Add `+inspect` shortcut for document URL inspection with wiki unwrapping (#947)
- **wiki**: Add `+node-get` / `+node-delete` / `+space-create` shortcuts (#904)
- **base**: Support Base attachment APIs (#887)
- **mail**: Validate `bot` + `mailbox=me` and add dynamic `--as` help tests (#895)
- **mail**: Expose draft priority in `--inspect` projection and document `--set-priority` (#779)

### Bug Fixes

- **identitydiag**: Harden verify path and tighten status semantics (#961)
- **wiki**: Surface real node URL for `+node-create` / `+node-copy` (#960)
- **auth**: Split bot and user identity diagnostics (#957)
- **base**: Address Base attachment review follow-ups (#958)
- **docs**: Clarify `replace_all` selection errors (#954)

### Documentation

- **drive**: Clarify add comment constraints (#967)
- **lark-im**: Clarify message activity search (#865)

### Tests

- Verify e2e resource cleanup (#949)
- **lint**: Exclude `bidichk` from test files (#959)

## [v1.0.33] - 2026-05-18

### Features

- **markdown**: Add `+patch` shortcut (#857)
- **slides**: Improve slide planning and validation guidance (#847)
- **drive**: Add `+sync` workflow for Drive directories (#873)
- **drive**: Add drive version shortcut (#841)
- **extension**: Plugin / Hook framework with command pruning (#910)

### Bug Fixes

- **sheets**: Explicitly document safe JSON unmarshal ignore in `DryRun` (#935)
- **base**: Mark base field update high risk (#936)
- **auth**: Guide agents to yield during auth device flow (#933)

### Documentation

- **lark-wiki**: Correct the `--as` default-identity claim (#919)

### Tests

- Drop stale e2e `--yes` flags (#920)

## [v1.0.32] - 2026-05-15

### Features

- **doc**: Add `--width`/`--height` flags to `docs +media-insert` (#832)
- **wiki**: Add `+space-list` / `+node-list` / `+node-copy` shortcuts (#392)

### Bug Fixes

- **drive**: Preserve parent token on nested overwrite (#908)
- **selfupdate**: Use `LookPath` instead of `Executable` for binary verification (#886)
- **registry**: Wait for background meta refresh before test reset (#894)

### Documentation

- **doc**: Add SVG whiteboard support to `lark-doc` v2 skill (#901)
- **drive**: Add permission public patch error guidance (#863)

## [v1.0.31] - 2026-05-14

### Features

- **install**: Skip interactive prompts in non-TTY environments (#888)
- **update**: Recommend `lark-cli update` over `npm install` for AI agents (#884)
- **im**: Add `--exclude-muted` to `+chat-search` and new `+chat-list` shortcut (#820)
- **auth**: Add `--exclude` flag and allow combining `--scope` with `--domain`/`--recommend` (#844)
- **drive**: Add modified-time smart sync mode (#859)
- **approval**: Add `tasks.add_sign` and `tasks.rollback` methods (#867)

## [v1.0.30] - 2026-05-13

### Features

- **im**: Add `--chat-mode topic` to `+chat-create` (#790)

### Bug Fixes

- **auth**: Support comma-separated `--scope` in `auth login` (#764)
- **auth**: Clarify URL handling in auth messages and docs (#856)
- **bind**: Accept `~/` paths in OpenClaw secret references (#839)

### Tests

- **update**: Isolate stamp writes from real `~/.lark-cli/skills.stamp` (#858)

## [v1.0.29] - 2026-05-12

### Features

- **vc**: Add agent meeting join, leave, and events shortcuts (#824)
- **mail**: Add unknown-flag fuzzy match for `lark-cli mail` commands (#806)
- **whiteboard**: Pin `whiteboard-cli` to `v0.2.11` in `lark-whiteboard` skill (#850)

### Bug Fixes

- Silence misleading "skills not installed" startup notice (#801)

### Documentation

- **base**: Refine data analysis SOP wording (#784, #849)
- Update README capability descriptions (#793)

## [v1.0.28] - 2026-05-11

### Features

- **im**: Support UAT for `messages.forward` and add `threads.forward` (#689)
- **im**: Add flag shortcuts `+flag-create` / `+flag-list` / `+flag-cancel` for message bookmarks (#770)

### Bug Fixes

- **drive**: Handle duplicate remote sync paths (#803)

### Documentation

- **im**: Name `--query` / `--member-ids` in `+chat-search` shortcut row (#812)

## [v1.0.27] - 2026-05-09

### Features

- **config**: Add `lark-channel` as a bind source (#786)

### Bug Fixes

- **install**: Fix installation errors when PowerShell is disabled by Group Policy (#789)

### Documentation

- **task**: Clarify task member id types in references (#777)

## [v1.0.26] - 2026-05-08

### Features

- **im**: Add `message_app_link` to message outputs (#668)
- **auth**: Add scope hint for missing authorization errors (#776)

### Bug Fixes

- **base**: Clean error detail output (#783)
- **whiteboard**: Reclassify `+update` as `write` risk (#775)

### Documentation

- **mail**: Add data integrity and write-confirmation rules (#749)

## [v1.0.25] - 2026-05-07

### Features

- Add skills version drift notice and unify update flow (#723)

### Bug Fixes

- Remove misleading default value from `--as` flag help text (#769)
- Handle negative truncate lengths (#744)
- Reject invalid JSON pointer escapes (#741)
- Migrate task shortcut errors to structured `output.Errorf`/`ErrValidation` (#740)

### Documentation

- Clarify base `user_open_id` guidance (#763)

## [v1.0.24] - 2026-05-06

### Features

- **sheets**: Add sheet management shortcuts (#722)
- **base**: Support batch record get and delete (#630)
- **task**: Add upload task attachment shortcut (#736)
- **drive**: Pre-flight 10000-rune total cap for `+add-comment` `reply_elements` (#605)

### Bug Fixes

- **auth**: Handle missing scopes and device flow improvements (#752)
- Add url to markdown `+create` output (#753)

### Documentation

- Refine field update conversion guidance (#748)

## [v1.0.23] - 2026-04-30

### Features

- **drive**: Add `+pull` shortcut for one-way Drive → local mirror (#696)
- **drive**: Add `+push` shortcut for one-way local → Drive mirror (#709)
- **drive**: Add `+status` shortcut for content-hash diff (#692)
- **drive**: Support `--file-name` for drive export (#685)
- **base**: Add markdown output for record reads (#726)
- **minutes**: Add media upload shortcut (#725)
- **doc**: Warn when callout uses `type=` without `background-color` (#467)
- **cmdutil**: Support `@file` for params and data (#724)
- Add markdown shortcuts and skill docs (#704)

### Documentation

- **doc**: Guide lark-doc v2 usage (#710)
- **minutes**: Clarify minutes file-to-notes routing (#732)

## [v1.0.22] - 2026-04-29

### Features

- **task**: Add resource agent & `agent_task_step_info` (#693)
- **task**: Support app task members by id (#712)
- **contact**: Add `--queries` multi-name fanout to `+search-user` (#707)
- **slides**: Add slide templates with template-first skill guidance (#684)
- **mail**: Support calendar events in emails (#646)
- **install**: Honor `npm_config_registry` for binary URL resolution with npmmirror fallback (#690)

### Bug Fixes

- **install**: Make Windows zip extraction resilient (#713)
- **config/init**: Respect `--brand` flag in `--new` mode (#711)

### Documentation

- **base**: Clarify base search routing (#708)
- **base**: Align base skills and view config contracts (#653)

## [v1.0.21] - 2026-04-28

### Features

- **contact**: Add search filters and richer profile fields to `+search-user` (#648)
- **common**: Backfill resource URL when create APIs omit it (#680)
- **risk**: Add risk tiering for command sensitivity classification (#633)
- **okr**: Add progress records support (#574)
- **calendar**: Enhance event search and meeting room finding (#679)
- **event**: Add event subscription & consume system (#654)
- **drive**: Extend `+add-comment` to support slides targets (#674)
- **slides**: Add font management for slides (#681)

### Bug Fixes

- **cmdutil**: Default flag completions to disabled (#688)
- **e2e/wiki**: Pass `obj_type` when deleting wiki nodes in cleanup (#687)
- **readme**: Fix readme statistics (#691)

## [v1.0.20] - 2026-04-27

### Features

- **drive**: Add `+search` shortcut with flat filter flags (#658)
- **mail**: Support sharing emails to IM chats via `+share-to-chat` (#637)
- **calendar**: Add `+update` shortcut (#678)
- **im**: Add `--at-chatter-ids` filter to `+messages-search` (#612)
- **pagination**: Preserve pagination state on truncation and natural end (#659)
- **lark-im**: Add `chat.members.bots` to skill docs (#616)

### Bug Fixes

- **strict-mode**: Reject explicit `--as` instead of silently overriding it (#673)
- **whiteboard**: Manual disable edge case for svg compatibility (#661)

### Documentation

- **lark-drive**: Add missing import command examples (#669)
- **readme**: Add Project (Meegle) to Features table (#660)

## [v1.0.19] - 2026-04-24

### Features

- **mail**: Add read receipt support — `--request-receipt` on compose, `+send-receipt` / `+decline-receipt` for response
- **doc**: Add v2 API for `docs +create` / `+fetch` / `+update` (#638)
- **im**: Request thread roots for chat message list (#635)
- **drive**: Support wiki node targets in `+upload` (#611)
- **config**: Block `auth` / `config` when external credential provider is active (#627)
- **whiteboard**: Pin `whiteboard-cli` to `v0.2.10` in `lark-whiteboard` skill (#649)

## [v1.0.18] - 2026-04-23

### Features

- **base**: Support `.base` import and export for bitable (#599)
- **config**: Add `config bind` for per-Agent credential isolation (#515)
- **slides**: Add `+replace-slide` shortcut for block-level XML edits (#516)
- **wiki**: Add `+delete-space` shortcut with async task polling (#610)
- **doc**: Add `--from-clipboard` flag to `docs +media-insert` (#508)
- **minutes**: Unify minute artifacts output to `./minutes/{minute_token}/` (#604)
- Add configurable content-safety scanning (#606)
- **install**: Add SHA-256 checksum verification to `install.js` (#592)
- **whiteboard**: Pin `whiteboard-cli` to `^0.2.9` (#617)

### Bug Fixes

- **drive**: Escape angle brackets in comment text (#632)
- **im**: Unify `messages-search` pagination int flags (#446)
- **im**: Fix markdown URL rendering issues in post content (#206)

### Documentation

- **base**: Refine record cell value guidance (#636)

## [v1.0.17] - 2026-04-22

### Features

- **im**: Use `Content-Disposition` filename when downloading message resources (#536)
- **drive**: Add `+apply-permission` to request doc access (#588)
- Support record share link (#466)
- **whiteboard**: Add image support to `whiteboard-cli` skill (#553)
- **cmdutil**: Add `X-Cli-Build` header for CLI build classification (#596)

### Bug Fixes

- **base**: Add default-table follow-up hint to `base-create` (#600)
- Skip flag-completion registration outside completion path (#598)
- Add `record-share-link-create` in `SKILL.md` (#597)
- **mail**: Remove leftover conflict marker in skill docs (#594)

### Documentation

- **drive**: Clarify that comment listing defaults to unresolved comments only (#609)
- **doc**: Fix `--markdown` examples that teach literal `\n` (#602)
- **mail**: Remove `get_signatures` from skill reference, exposed via `+signature` instead (#545)

## [v1.0.16] - 2026-04-21

### Features

- **mail**: Support large email attachments (#537)
- **mail**: Add draft preview URL to draft operations (#438)
- **doc**: Add pre-write semantic warnings to `docs +update` (#569)
- **doc**: Add `--selection-with-ellipsis` position flag to `+media-insert` (#335)
- **calendar**: Support event share link and error details (#583)

### Bug Fixes

- **doc**: Preserve round-trip formatting in `+fetch` output (#469)
- **docs**: Validate `--selection-by-title` format early (#256)
- **whiteboard**: Register `+media-upload` shortcut and add whiteboard parent type

### Refactor

- Split `Execute` into `Build` + `Execute` with explicit IO and keychain injection (#371)
- **auth**: Simplify scope reporting in login flow (#582)

## [v1.0.15] - 2026-04-20

### Features

- **sheets**: Add float image shortcuts (#494)
- **approval**: Document `remind` and `initiated` methods in skill (#554)

### Bug Fixes

- **base**: Preserve attachment metadata on base uploads (#563)
- **base**: Fix role view and record default permission on edit (#530)
- **sheets**: Normalize single-cell range in `+set-style` and `+batch-set-style` (#548)
- **im**: Cap `basic_batch` user_ids at 10 per API limit (#551)
- **install**: Refine install wizard messages (#529)
- **whiteboard**: Deprecate old `lark-whiteboard-cli` skill (#547)

## [v1.0.14] - 2026-04-17

### Features

- **mail**: Add email priority support for compose and read (#538)
- **mail**: Support scheduled send (#534)
- **drive**: Support sheet cell comments in `+add-comment` (#518)
- **doc**: Add `--file-view` flag to `+media-insert` (#419)
- **base**: Auto grant current user for bot create and copy (#497)
- **base**: Add identity priority strategy and error handling (#505)
- **auth**: Improve login scope handling and messages (#523)
- Add OKR business domain (#522)

### Documentation

- **wiki**: Improve wiki skill docs and add wiki domain template (#512)
- **task**: Document `custom_fields` and `custom_field_options` API resources and permissions (#524)

### Refactor

- **skills**: Introduce `lark-doc-whiteboard.md` and streamline whiteboard workflow (#502)

## [v1.0.13] - 2026-04-16

### Features

- **im**: Support user access token for file, image, audio, and video upload, aligning upload and send identity with `--as` flag (#474)
- **drive**: Add `drive +create-folder` shortcut with root-folder fallback and bot-mode auto-grant (#470)
- **wiki**: Add bot-mode auto-grant support to `wiki +node-create` (#470)
- **doc**: Default `skip_task_detail` in `docs +fetch` to reduce unnecessary task detail expansion (#471)

### Bug Fixes

- **im**: Preserve original URL filename for uploaded file messages instead of generic `media.ext` names (#514)
- **whiteboard**: Use atomic overwrite API parameter for `whiteboard +update`, replacing read-then-delete approach (#483)

### Documentation

- **base**: Unify record batch write limit to 200 and enforce serial writes for continuous operations (#499)
- **base**: Remove redundant reference documentation and command grouping chapters from SKILL.md (#500)

### CI

- Consolidate workflows into layered CI pyramid with single `results` gate (#510)

## [v1.0.12] - 2026-04-15

### Features

- Add guided npm install flow that installs or upgrades the CLI, installs AI skills, and walks through app config and auth login (#464)
- **mail**: Add email signature support with `+signature`, `--signature-id` compose flags, and draft signature edit operations (#485)
- **mail**: Return recall hints for sent emails when recall is available (#481)
- **slides**: Add `+media-upload` and support `@path` image placeholders in `+create --slides` (#450)

### Documentation

- **mail**: Add recipient search guidance to the mail skill workflow (#437)
- **calendar/vc**: Route past meeting queries to `lark-vc` and clarify historical date matching in skills (#482, #480)

## [v1.0.11] - 2026-04-14

### Features

- **sheets**: Add dropdown shortcuts for data validation management (`+set-dropdown`, `+update-dropdown`, `+get-dropdown`, `+delete-dropdown`) (#461)
- **task**: Add task search, tasklist search, related-task, set-ancestor, and subscribe-event shortcuts (#377)
- Streamline interactive login by removing the extra auth confirmation step (#451)

### Bug Fixes

- **base**: Validate JSON object inputs for base shortcuts and reject `null` objects (#458)

### Documentation

- **sheets**: Document value formats for formulas and special field types (#456)
- **readme**: Add Attendance to the features table (#460)

## [v1.0.10] - 2026-04-13

### Features

- **im**: Support im oapi range download for large files (#283)
- **sheets**: Add filter view and condition shortcuts (#422)
- **wiki**: Add wiki move shortcut with async task polling (#436)
- **drive**: Add drive `+create-shortcut` shortcut (#432)
- **drive**: Add drive files patch metadata API (#444)
- **task**: Support `--section-guid` flag in tasklist-task-add shortcut (#430)

### Bug Fixes

- **base**: Support large base attachment uploads (#441)
- **config**: Clarify init copy for TTY, preserve original for AI (#448)
- **im**: Reject `--user-id` under bot identity for chat-messages-list (#340)
- **mail**: Add missing scopes for mail `+watch` shortcut (#357)
- **mail**: Restrict `--output-dir` to current working directory (#376)

### Documentation

- **wiki**: Add wiki member operations to lark-wiki skill (#417)
- **task**: Document sections API resources, permissions, and URL parsing (#430)
- **doc**: Clarify when markdown escaping is needed (#312)

## [v1.0.9] - 2026-04-11

### Features

- Add attendance `user_task.query` (#405)
- Support minutes search (#359)
- **slides**: Add slides `+create` shortcut with `--slides` one-step creation (#389)
- **slides**: Return presentation URL in slides `+create` output (#425)
- **sheets**: Add dimension shortcuts for row/column operations (#413)
- **sheets**: Add cell operation shortcuts for merge, replace, and style (#412)
- **drive**: Add drive folder delete shortcut with async task polling (#415)

### Documentation

- **drive**: Add guide for granting document permission to current bot (#414)

## [v1.0.8] - 2026-04-10

### Features

- Add `update` command with self-update, verification, and rollback (#391)
- Add `--file` flag for multipart/form-data file uploads (#395)
- Support file comment reply reactions (#380)
- **base**: Add `+dashboard-arrange` command for auto-arranging dashboard blocks layout and `text` block type with Markdown support (#388)
- **base**: Add record batch `+add` / `+set` shortcuts (#277)
- **base**: Add `+record-search` for keyword-based record search (#328)
- **base**: Add view visible fields `+get` / `+set` shortcuts (#326)
- **base**: Add record field filters (#327)
- **base**: Optimize workflow skills (#345)
- **calendar**: Add room find workflow (#403)
- **mail**: Add `--page-token` and `--page-size` to mail `+triage` (#301)
- **whiteboard**: Add `+query` shortcut and enhance `+update` with Mermaid/PlantUML support (#382)

### Bug Fixes

- Improve error hints for sandbox and initialization issues (#384)
- Fix markdown line breaks support (#338)
- Return raw base field and view responses (#378)
- **base**: Return raw table list response and clarify sort help (#393)
- **calendar**: Add default video meeting to `+create` (#383)
- **mail**: Replace `os.Exit` with graceful shutdown in mail watch (#350)

### Documentation

- **base**: Document Base attachment download via docs `+media-download` (#404)
- Reorganize lark-base skill guidance (#374)

## [v1.0.7] - 2026-04-09

### Features

- Auto-grant current user access for bot-created docs, sheets, imports, and uploads (#360)
- **mail**: Add `send_as` alias support, mailbox/sender discovery APIs, and mail rules API
- **vc**: Extract note doc tokens from calendar event relation API (#333)
- **wiki**: Add wiki node create shortcut (#320)
- **sheets**: Add `+write-image` shortcut (#343)
- **docs**: Add media-preview shortcut (#334)
- **docs**: Add support for additional search filters (#353)

### Bug Fixes

- **api**: Support stdin and quoted JSON inputs on Windows (#367)
- **doc**: Post-process `docs +fetch` output to improve round-trip fidelity (#214)
- **run**: Add missing binary check for lark-cli execution (#362)
- **config**: Validate appId and appSecret keychain key consistency (#295)

### Refactor

- Route base import guidance to drive `+import` (#368)
- Migrate mail shortcuts to FileIO (#356)
- Migrate drive/doc/sheets shortcuts to FileIO (#339)
- Migrate base shortcuts to FileIO (#347)

### Documentation

- **lark-doc**: Document advanced boolean and intitle search syntax for AI agents (#210)

### Chore

- Add depguard and forbidigo rules to guide FileIO adoption (#342)

## [v1.0.6] - 2026-04-08

### Features

- Improve login scope validation and success output (#317)
- **task**: Support starting pagination from page token (#332)
- Support multipart doc media uploads (#294)
- **mail**: Auto-resolve local image paths in all draft entry points (#205)
- **vc**: Add `+recording` shortcut for `meeting_id` to `minute_token` conversion (#246)

### Bug Fixes

- Resolve concurrency races in RuntimeContext (#330)
- **config**: Save empty config before clearing keychain entries (#291)
- Reject positional arguments in shortcuts (#227)
- Improve raw API diagnostics for invalid or empty JSON responses (#257)
- **docs**: Normalize `board_tokens` in `+create` response for mermaid/whiteboard content (#10)
- **task**: Clarify `--complete` flag help for `get-my-tasks` (#310)
- **help**: Point root help Agent Skills link to README section (#289)

### Documentation

- Clarify `--complete` flag behavior in `get-my-tasks` reference (#308)

### Refactor

- Migrate VC/minutes shortcuts to FileIO (#336)
- Migrate common/client/IM to FileIO and add localfileio tests (#322)

## [v1.0.5] - 2026-04-07

### Features

- **drive**: Support multipart upload for files larger than 20MB (#43)
- Add darwin file master key fallback for keychain writes (#285)
- Add strict mode identity filter, profile management and credential extension (#252)

### Bug Fixes

- **mail**: Restore CID validation and stale PartID lookup lost in revert (#230)
- **base**: Clarify table-id `tbl` prefix requirement (#270)
- Fix parameter constraints for LarkMessageTrigger (#213)

### Documentation

- Fix root calendar example (#299)
- Fix README auth scope and api data flag (#298)
- Clarify task guid for applinks (#287)
- Clarify lark task guid usage (#282)
- **lark-base**: Add `has_more` guidance for record-list pagination (#183)

### Tests

- Isolate registry package state in tests (#280)

### CI

- Add scheduled issue labeler for type/domain triage (#251)
- **issue-labels**: Reduce mislabeling and handle missing labels (#288)
- Map wiki paths in pr labels (#249)

## [v1.0.4] - 2026-04-03

### Features

- Support user identity for im `+chat-create` (#242)
- Implement authentication response logging (#235)
- Support im chat member delete and add scope notes (#229)

### Bug Fixes

- **security**: Replace `http.DefaultTransport` with proxy-aware base transport to mitigate MITM risk (#247)
- **calendar**: Block auto bot fallback without user login (#245)

### Documentation

- **mail**: Add identity guidance to prefer user over bot (#157)

### Refactor

- **dashboard**: Restructure docs for AI-friendly navigation (#191)

### CI

- Add a CLI E2E testing framework for lark-cli, task domain testcase and ci action (#236)

## [v1.0.3] - 2026-04-02

### Features

- Add `--jq` flag for filtering JSON output (#211)
- Add `+download` shortcut for minutes media download (#101)
- Add drive import, export, move, and task result shortcuts (#194)
- Support im message send/reply with uat (#180)
- Add approve domain (#217)

### Bug Fixes

- **mail**: Use in-memory keyring in mail scope tests to avoid macOS keychain popups (#212)
- **mail**: On-demand scope checks and watch event filtering (#198)
- Use curl for binary download to support proxy and add npmmirror fallback (#226)
- Normalize escaped sheet range separators (#207)

### Documentation

- **mail**: Clarify JSON output is directly usable without extra encoding (#228)
- Clarify docs search query usage (#221)

### CI

- Add gitleaks scanning workflow and custom rules (#142)

## [v1.0.2] - 2026-04-01

### Features

- Improve OS keychain/DPAPI access error handling for sandbox environments (#173)
- **mail**: Auto-resolve local image paths in draft body HTML (#139)

### Bug Fixes

- Correct URL formatting in login `--no-wait` output (#169)

### Documentation

- Add concise AGENTS development guide (#178)

### CI

- Refine PR business area labels and introduce skill format check (#148)

### Chore

- Add pull request template (#176)

## [v1.0.1] - 2026-03-31

### Features

- Add automatic CLI update detection and notification (#144)
- Add npm publish job to release workflow (#145)
- Support auto extension for downloads (#16)
- Remove useless files (#131)
- Normalize markdown message send/reply output (#28)
- Add auto-pagination to messages search and update lark-im docs (#30)

### Bug Fixes

- **base**: Use base history read scope for record history list (#96)
- Remove sensitive send scope from reply and forward shortcuts (#92)
- Resolve silent failure in `lark-cli api` error output (#85)

### Documentation

- **base**: Clarify field description usage in json (#90)
- Update Base description to include all capabilities (#61)
- Add official badge to distinguish from third-party Lark CLI tools (#103)
- Rename user-facing Bitable references to Base (#11)
- Add star history chart to readmes (#12)
- Simplify installation steps by merging CLI and Skills into one section (#26)
- Add npm version badge and improve AI agent tip wording (#23)
- Emphasize Skills installation as required for AI Agents (#19)
- Clarify install methods as alternatives and add source build steps

### CI

- Improve CI workflows and add golangci-lint config (#71)

## [v1.0.0] - 2026-03-28

### Initial Release

The first open-source release of **Lark CLI** — the official command-line interface for [Lark/Feishu](https://www.larksuite.com/).

### Features

#### Core Commands

- **`lark api`** — Make arbitrary Lark Open API calls directly from the terminal with flexible parameter support.
- **`lark auth`** — Complete OAuth authentication flow, including interactive login, logout, token status, and scope management.
- **`lark config`** — Manage CLI configuration, including `init` for guided setup and `default-as` for switching contexts.
- **`lark schema`** — Inspect available API services and resource schemas.
- **`lark doctor`** — Run diagnostic checks on CLI configuration and environment.
- **`lark completion`** — Generate shell completion scripts for Bash, Zsh, Fish, and PowerShell.

#### Service Shortcuts

Built-in shortcuts for commonly used Lark APIs, enabling concise commands like `lark im send` or `lark drive upload`:

- **IM (Messaging)** — Send messages, manage chats, and more.
- **Drive** — Upload, download, and manage cloud documents.
- **Docs** — Work with Lark documents.
- **Sheets** — Interact with spreadsheets.
- **Base** — Manage multi-dimensional tables.
- **Calendar** — Create and manage calendar events.
- **Mail** — Send and manage emails.
- **Contact** — Look up users and departments.
- **Task** — Create and manage tasks.
- **Event** — Subscribe to and manage event callbacks.
- **VC (Video Conference)** — Manage meetings.
- **Whiteboard** — Interact with whiteboards.

#### AI Agent Skills

Bundled AI agent skills for intelligent assistance:

- `lark-im`, `lark-doc`, `lark-drive`, `lark-sheets`, `lark-base`, `lark-calendar`, `lark-mail`, `lark-contact`, `lark-task`, `lark-event`, `lark-vc`, `lark-whiteboard`, `lark-wiki`, `lark-minutes`
- `lark-openapi-explorer` — Explore and discover Lark APIs interactively.
- `lark-skill-maker` — Create custom AI skills.
- `lark-workflow-meeting-summary` — Automated meeting summary workflow.
- `lark-workflow-standup-report` — Automated standup report workflow.
- `lark-shared` — Shared skill utilities.

#### Developer Experience

- Cross-platform support (macOS, Linux, Windows) via GoReleaser.
- Shell completion for Bash, Zsh, Fish, and PowerShell.
- Bilingual documentation (English & Chinese).
- CI/CD pipelines: linting, testing, coverage reporting, and automated releases.

[v1.0.100]: https://github.com/larksuite/cli/releases/tag/v1.0.100
[v1.0.99]: https://github.com/larksuite/cli/releases/tag/v1.0.99
[v1.0.98]: https://github.com/larksuite/cli/releases/tag/v1.0.98
[v1.0.97]: https://github.com/larksuite/cli/releases/tag/v1.0.97
[v1.0.96]: https://github.com/larksuite/cli/releases/tag/v1.0.96
[v1.0.95]: https://github.com/larksuite/cli/releases/tag/v1.0.95
[v1.0.94]: https://github.com/larksuite/cli/releases/tag/v1.0.94
[v1.0.93]: https://github.com/larksuite/cli/releases/tag/v1.0.93
[v1.0.92]: https://github.com/larksuite/cli/releases/tag/v1.0.92
[v1.0.91]: https://github.com/larksuite/cli/releases/tag/v1.0.91
[v1.0.90]: https://github.com/larksuite/cli/releases/tag/v1.0.90
[v1.0.89]: https://github.com/larksuite/cli/releases/tag/v1.0.89
[v1.0.88]: https://github.com/larksuite/cli/releases/tag/v1.0.88
[v1.0.87]: https://github.com/larksuite/cli/releases/tag/v1.0.87
[v1.0.86]: https://github.com/larksuite/cli/releases/tag/v1.0.86
[v1.0.85]: https://github.com/larksuite/cli/releases/tag/v1.0.85
[v1.0.84]: https://github.com/larksuite/cli/releases/tag/v1.0.84
[v1.0.83]: https://github.com/larksuite/cli/releases/tag/v1.0.83
[v1.0.82]: https://github.com/larksuite/cli/releases/tag/v1.0.82
[v1.0.81]: https://github.com/larksuite/cli/releases/tag/v1.0.81
[v1.0.80]: https://github.com/larksuite/cli/releases/tag/v1.0.80
[v1.0.79]: https://github.com/larksuite/cli/releases/tag/v1.0.79
[v1.0.78]: https://github.com/larksuite/cli/releases/tag/v1.0.78
[v1.0.77]: https://github.com/larksuite/cli/releases/tag/v1.0.77
[v1.0.75]: https://github.com/larksuite/cli/releases/tag/v1.0.75
[v1.0.74]: https://github.com/larksuite/cli/releases/tag/v1.0.74
[v1.0.73]: https://github.com/larksuite/cli/releases/tag/v1.0.73
[v1.0.72]: https://github.com/larksuite/cli/releases/tag/v1.0.72
[v1.0.71]: https://github.com/larksuite/cli/releases/tag/v1.0.71
[v1.0.70]: https://github.com/larksuite/cli/releases/tag/v1.0.70
[v1.0.69]: https://github.com/larksuite/cli/releases/tag/v1.0.69
[v1.0.68]: https://github.com/larksuite/cli/releases/tag/v1.0.68
[v1.0.67]: https://github.com/larksuite/cli/releases/tag/v1.0.67
[v1.0.66]: https://github.com/larksuite/cli/releases/tag/v1.0.66
[v1.0.65]: https://github.com/larksuite/cli/releases/tag/v1.0.65
[v1.0.64]: https://github.com/larksuite/cli/releases/tag/v1.0.64
[v1.0.62]: https://github.com/larksuite/cli/releases/tag/v1.0.62
[v1.0.61]: https://github.com/larksuite/cli/releases/tag/v1.0.61
[v1.0.60]: https://github.com/larksuite/cli/releases/tag/v1.0.60
[v1.0.59]: https://github.com/larksuite/cli/releases/tag/v1.0.59
[v1.0.58]: https://github.com/larksuite/cli/releases/tag/v1.0.58
[v1.0.57]: https://github.com/larksuite/cli/releases/tag/v1.0.57
[v1.0.56]: https://github.com/larksuite/cli/releases/tag/v1.0.56
[v1.0.55]: https://github.com/larksuite/cli/releases/tag/v1.0.55
[v1.0.54]: https://github.com/larksuite/cli/releases/tag/v1.0.54
[v1.0.53]: https://github.com/larksuite/cli/releases/tag/v1.0.53
[v1.0.52]: https://github.com/larksuite/cli/releases/tag/v1.0.52
[v1.0.51]: https://github.com/larksuite/cli/releases/tag/v1.0.51
[v1.0.50]: https://github.com/larksuite/cli/releases/tag/v1.0.50
[v1.0.49]: https://github.com/larksuite/cli/releases/tag/v1.0.49
[v1.0.48]: https://github.com/larksuite/cli/releases/tag/v1.0.48
[v1.0.47]: https://github.com/larksuite/cli/releases/tag/v1.0.47
[v1.0.46]: https://github.com/larksuite/cli/releases/tag/v1.0.46
[v1.0.45]: https://github.com/larksuite/cli/releases/tag/v1.0.45
[v1.0.44]: https://github.com/larksuite/cli/releases/tag/v1.0.44
[v1.0.43]: https://github.com/larksuite/cli/releases/tag/v1.0.43
[v1.0.42]: https://github.com/larksuite/cli/releases/tag/v1.0.42
[v1.0.41]: https://github.com/larksuite/cli/releases/tag/v1.0.41
[v1.0.40]: https://github.com/larksuite/cli/releases/tag/v1.0.40
[v1.0.39]: https://github.com/larksuite/cli/releases/tag/v1.0.39
[v1.0.38]: https://github.com/larksuite/cli/releases/tag/v1.0.38
[v1.0.37]: https://github.com/larksuite/cli/releases/tag/v1.0.37
[v1.0.36]: https://github.com/larksuite/cli/releases/tag/v1.0.36
[v1.0.35]: https://github.com/larksuite/cli/releases/tag/v1.0.35
[v1.0.34]: https://github.com/larksuite/cli/releases/tag/v1.0.34
[v1.0.33]: https://github.com/larksuite/cli/releases/tag/v1.0.33
[v1.0.32]: https://github.com/larksuite/cli/releases/tag/v1.0.32
[v1.0.31]: https://github.com/larksuite/cli/releases/tag/v1.0.31
[v1.0.30]: https://github.com/larksuite/cli/releases/tag/v1.0.30
[v1.0.29]: https://github.com/larksuite/cli/releases/tag/v1.0.29
[v1.0.28]: https://github.com/larksuite/cli/releases/tag/v1.0.28
[v1.0.27]: https://github.com/larksuite/cli/releases/tag/v1.0.27
[v1.0.26]: https://github.com/larksuite/cli/releases/tag/v1.0.26
[v1.0.25]: https://github.com/larksuite/cli/releases/tag/v1.0.25
[v1.0.24]: https://github.com/larksuite/cli/releases/tag/v1.0.24
[v1.0.23]: https://github.com/larksuite/cli/releases/tag/v1.0.23
[v1.0.22]: https://github.com/larksuite/cli/releases/tag/v1.0.22
[v1.0.21]: https://github.com/larksuite/cli/releases/tag/v1.0.21
[v1.0.20]: https://github.com/larksuite/cli/releases/tag/v1.0.20
[v1.0.19]: https://github.com/larksuite/cli/releases/tag/v1.0.19
[v1.0.18]: https://github.com/larksuite/cli/releases/tag/v1.0.18
[v1.0.17]: https://github.com/larksuite/cli/releases/tag/v1.0.17
[v1.0.16]: https://github.com/larksuite/cli/releases/tag/v1.0.16
[v1.0.15]: https://github.com/larksuite/cli/releases/tag/v1.0.15
[v1.0.14]: https://github.com/larksuite/cli/releases/tag/v1.0.14
[v1.0.13]: https://github.com/larksuite/cli/releases/tag/v1.0.13
[v1.0.12]: https://github.com/larksuite/cli/releases/tag/v1.0.12
[v1.0.11]: https://github.com/larksuite/cli/releases/tag/v1.0.11
[v1.0.10]: https://github.com/larksuite/cli/releases/tag/v1.0.10
[v1.0.9]: https://github.com/larksuite/cli/releases/tag/v1.0.9
[v1.0.8]: https://github.com/larksuite/cli/releases/tag/v1.0.8
[v1.0.7]: https://github.com/larksuite/cli/releases/tag/v1.0.7
[v1.0.6]: https://github.com/larksuite/cli/releases/tag/v1.0.6
[v1.0.5]: https://github.com/larksuite/cli/releases/tag/v1.0.5
[v1.0.4]: https://github.com/larksuite/cli/releases/tag/v1.0.4
[v1.0.3]: https://github.com/larksuite/cli/releases/tag/v1.0.3
[v1.0.2]: https://github.com/larksuite/cli/releases/tag/v1.0.2
[v1.0.1]: https://github.com/larksuite/cli/releases/tag/v1.0.1
[v1.0.0]: https://github.com/larksuite/cli/releases/tag/v1.0.0
